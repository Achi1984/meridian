# ACHI MERIDIAN v5.6.2 — CACHEFIX

Der Screenshot zeigte weiterhin v5.6.0. Ursache: alte PWA-/Service-Worker-Dateien wurden weiter ausgeliefert.

Fix:
- sichtbare Version überall auf v5.6.2 aktualisiert
- JS/CSS mit hartem Cache-Busting
- neuer Service Worker mit neuer Cache-ID
- skipWaiting + clients.claim
- Network-first für lokale App-Dateien
- RESET.html löscht alte Service Worker und Caches
- UI-Polish aus v5.6.1 bleibt enthalten
