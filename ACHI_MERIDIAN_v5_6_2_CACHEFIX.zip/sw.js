const CACHE='meridian-v5.6.2-cachefix';
const ASSETS=["styles-v5.1.5.css", "history.json", "version.json", "icon-192.png", "icon-512.png", "index.html", "IPHONE-ANLEITUNG.txt", "data.json", "achi-meridian-logo.png", "manifest.webmanifest", "app-v5.5.0.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(
  caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
  .then(()=>self.clients.claim())
));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  const u=new URL(e.request.url);
  if(u.origin!==location.origin) return;
  e.respondWith(
    fetch(e.request).then(r=>{
      const copy=r.clone();
      caches.open(CACHE).then(c=>c.put(e.request,copy));
      return r;
    }).catch(()=>caches.match(e.request).then(r=>r||caches.match(u.pathname.split('/').pop())))
  );
});
